import os
from tempfile import NamedTemporaryFile

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from waitress import serve
from werkzeug.utils import secure_filename

from config import ALLOWED_SORT_FIELDS, UPLOAD_FOLDER
from db import get_db_connection, init_db, normalize_shpi, normalize_internal_number, normalize_search_text
from watchdog_handler import start_watchdog

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024

ALLOWED_PER_PAGE = {20, 50, 100, 200}


def parse_positive_int(value, default=1, minimum=1, maximum=None):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    if number < minimum:
        return minimum
    if maximum is not None and number > maximum:
        return maximum
    return number


def build_filters():
    search = request.args.get("search", "").strip()
    q_shpi = request.args.get("q_shpi") is not None
    q_recipient = request.args.get("q_recipient") is not None
    q_address = request.args.get("q_address") is not None
    q_internal_number = request.args.get("q_internal_number") is not None
    q_comment = request.args.get("q_comment") is not None
    date_from = request.args.get("dateFrom", "").strip()
    date_to = request.args.get("dateTo", "").strip()

    where_clauses, params = [], []

    if search:
        fields = []
        pattern = f"%{normalize_search_text(search)}%"

        if not any((q_shpi, q_recipient, q_address, q_internal_number, q_comment)):
            fields.extend([
                "shpi_normalized LIKE ?",
                "recipient_normalized LIKE ?",
                "address_normalized LIKE ?",
                "internal_number_normalized LIKE ?",
                "comment_normalized LIKE ?",
            ])
            params.extend([pattern] * 5)
        else:
            if q_shpi:
                fields.append("shpi_normalized LIKE ?")
                params.append(f"%{normalize_shpi(search)}%")
            if q_recipient:
                fields.append("recipient_normalized LIKE ?")
                params.append(pattern)
            if q_address:
                fields.append("address_normalized LIKE ?")
                params.append(pattern)
            if q_internal_number:
                fields.append("internal_number_normalized LIKE ?")
                params.append(f"%{normalize_internal_number(search)}%")
            if q_comment:
                fields.append("comment_normalized LIKE ?")
                params.append(pattern)

        if fields:
            where_clauses.append("(" + " OR ".join(fields) + ")")

    if date_from:
        where_clauses.append("uploaded_at >= ?")
        params.append(f"{date_from} 00:00:00")
    if date_to:
        where_clauses.append("uploaded_at <= ?")
        params.append(f"{date_to} 23:59:59")

    where = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    return {
        "where": where, "params": params, "search": search,
        "date_from": date_from, "date_to": date_to,
        "q_shpi": q_shpi, "q_recipient": q_recipient,
        "q_address": q_address, "q_internal_number": q_internal_number,
        "q_comment": q_comment,
    }


@app.route("/")
def index():
    page = parse_positive_int(request.args.get("page", 1), 1, 1)
    per_page = parse_positive_int(request.args.get("per_page", 50), 50, 20, 200)
    if per_page not in ALLOWED_PER_PAGE:
        per_page = 50

    sort_by = request.args.get("sortBy", "id")
    order = request.args.get("order", "desc").lower()
    if sort_by not in ALLOWED_SORT_FIELDS:
        sort_by = "id"
    order_norm = "DESC" if order == "desc" else "ASC"

    filters = build_filters()
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS total FROM shipments" + filters["where"], filters["params"])
    total = cur.fetchone()["total"]
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = min(page, total_pages)
    offset = (page - 1) * per_page

    query = f"""
        SELECT id, shpi, mass, shipping_cost, recipient, phone, index_code,
               address, internal_number, comment, uploaded_at
        FROM shipments
        {filters["where"]}
        ORDER BY {sort_by} {order_norm}
        LIMIT ? OFFSET ?
    """
    cur.execute(query, filters["params"] + [per_page, offset])
    shipments = [dict(row) for row in cur.fetchall()]
    conn.close()

    return render_template(
        "PartPostCrimea.html",
        shipments=shipments, current_page=page, total_pages=total_pages,
        total_count=total, per_page=per_page, search=filters["search"],
        date_from=filters["date_from"], date_to=filters["date_to"],
        q_shpi=filters["q_shpi"], q_recipient=filters["q_recipient"],
        q_address=filters["q_address"],
        q_internal_number=filters["q_internal_number"],
        q_comment=filters["q_comment"], sortBy=sort_by, order=order,
    )


@app.route("/api/shipment")
def find_shipment():
    raw_shpi = request.args.get("shpi", "")
    shpi = normalize_shpi(raw_shpi)
    if not shpi:
        return jsonify(success=False, found=False, message="Введите номер отправления"), 400

    conn = get_db_connection()
    row = conn.execute("""
        SELECT id, shpi, mass, shipping_cost, recipient, phone, index_code,
               address, internal_number, comment, uploaded_at
        FROM shipments
        WHERE shpi_normalized = ?
        LIMIT 1
    """, (shpi,)).fetchone()
    conn.close()

    if row is None:
        return jsonify(success=True, found=False, message="Отправление не найдено")
    return jsonify(success=True, found=True, shipment=dict(row))


@app.route("/api/internal-number")
def find_by_internal_number():
    raw_number = request.args.get("number", "")
    number = normalize_internal_number(raw_number)
    if not number:
        return jsonify(success=False, found=False, message="Введите внутренний номер"), 400

    conn = get_db_connection()
    rows = conn.execute("""
        SELECT id, shpi, mass, shipping_cost, recipient, phone, index_code,
               address, internal_number, comment, uploaded_at
        FROM shipments
        WHERE internal_number_normalized = ?
        ORDER BY id DESC
        LIMIT 100
    """, (number,)).fetchall()
    conn.close()

    return jsonify(
        success=True,
        found=bool(rows),
        shipments=[dict(row) for row in rows],
        message=None if rows else "Отправления с таким внутренним номером не найдены",
    )


@app.route("/api/stats")
def api_stats():
    conn = get_db_connection()
    row = conn.execute("""
        SELECT COUNT(*) AS total, COUNT(DISTINCT index_code) AS indexes,
               MAX(uploaded_at) AS last_upload
        FROM shipments
    """).fetchone()
    conn.close()
    return jsonify(success=True, stats=dict(row))


@app.route("/upload-page")
def upload_page():
    return render_template("UploadPage.html")


@app.route("/upload", methods=["POST"])
def upload_file():
    from excel_processor import process_xlsx_file

    if "file" not in request.files or not request.files["file"] or request.files["file"].filename == "":
        flash("Необходимо выбрать файл", "error")
        return redirect(url_for("upload_page"))

    file = request.files["file"]
    filename = secure_filename(file.filename)
    if not filename.lower().endswith(".xlsx"):
        flash("Поддерживаются только файлы Excel формата .xlsx", "error")
        return redirect(url_for("upload_page"))

    temp_path = None
    try:
        with NamedTemporaryFile(delete=False, suffix=".xlsx") as temp_file:
            temp_path = temp_file.name
            file.save(temp_path)

        success, message = process_xlsx_file(temp_path, delete_source=True)
        flash(("Готово! " if success else "Ошибка обработки: ") + message, "success" if success else "error")
    except Exception as exc:
        flash(f"Ошибка загрузки файла: {exc}", "error")
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass

    return redirect(url_for("index"))


@app.errorhandler(413)
def file_too_large(_error):
    flash("Размер файла превышает допустимый лимит 100 МБ", "error")
    return redirect(url_for("upload_page"))


if __name__ == "__main__":
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    init_db()
    observer = start_watchdog(UPLOAD_FOLDER)
    try:
        serve(app, host="0.0.0.0", port=5000, threads=8)
    except KeyboardInterrupt:
        print("\n[APP] Остановка приложения...")
    finally:
        observer.stop()
        observer.join()
