import math
import os
from datetime import datetime
from sqlite3 import IntegrityError

from openpyxl import load_workbook

from config import FIELD_MAP
from db import (
    get_db_connection,
    normalize_internal_number,
    normalize_search_text,
    normalize_shpi,
)

BATCH_SIZE = 500


def normalize_header(value):
    if value is None:
        return ""
    text = str(value).strip().lower()
    for source, target in {
        " ": "_", "-": "_", "–": "_", "—": "_",
        ".": "", ",": "", ":": "", "/": "_", "\\": "_",
    }.items():
        text = text.replace(source, target)
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_")


def clean_text(value):
    return "" if value is None else str(value).strip()


def clean_number(value):
    if value is None or value == "" or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return None if isinstance(value, float) and math.isnan(value) else float(value)
    text = str(value).strip().replace("₽", "").replace("руб.", "").replace("руб", "").replace(" ", "").replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return None


def build_mapping(headers):
    mapping = {field: None for field in FIELD_MAP}
    for index, header in enumerate(headers):
        for field, keywords in FIELD_MAP.items():
            if mapping[field] is not None:
                continue
            for keyword in keywords:
                normalized_keyword = normalize_header(keyword)
                if normalized_keyword == header or normalized_keyword in header:
                    mapping[field] = index
                    break
    return mapping


def process_xlsx_file(file_path, delete_source=False):
    workbook = conn = None
    inserted = duplicates = errors = skipped_empty = 0
    upload_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        workbook = load_workbook(file_path, data_only=True, read_only=True)
        worksheet = workbook.active
        if worksheet.max_row < 2:
            return False, "Файл не содержит строк для загрузки"

        headers = [normalize_header(cell.value) for cell in next(worksheet.iter_rows(min_row=1, max_row=1))]
        mapping = build_mapping(headers)
        missing = [field for field, index in mapping.items() if index is None]
        if missing:
            return False, "Не найдены обязательные колонки: " + ", ".join(missing)

        conn = get_db_connection()
        cur = conn.cursor()
        sql = """
            INSERT INTO shipments (
                shpi, shpi_normalized, mass, shipping_cost,
                recipient, recipient_normalized, phone, index_code,
                address, address_normalized,
                internal_number, internal_number_normalized,
                comment, comment_normalized, uploaded_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        batch = []

        def flush_batch():
            nonlocal inserted, duplicates, errors, batch
            for item in batch:
                try:
                    cur.execute(sql, item)
                    inserted += 1
                except IntegrityError:
                    duplicates += 1
                except Exception as exc:
                    errors += 1
                    print(f"[IMPORT] Ошибка записи: {exc}")
            batch = []

        for row_index, row in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
            try:
                shpi = clean_text(row[mapping["shpi"]])
                if not shpi:
                    skipped_empty += 1
                    continue
                shpi_normalized = normalize_shpi(shpi)
                if not shpi_normalized:
                    skipped_empty += 1
                    continue

                recipient = clean_text(row[mapping["recipient"]])
                address = clean_text(row[mapping["address"]])
                internal_number = clean_text(row[mapping["internal_number"]])
                comment = clean_text(row[mapping["comment"]])

                batch.append((
                    shpi, shpi_normalized,
                    clean_number(row[mapping["mass"]]),
                    clean_number(row[mapping["shipping_cost"]]),
                    recipient, normalize_search_text(recipient),
                    clean_text(row[mapping["phone"]]),
                    clean_text(row[mapping["index_code"]]),
                    address, normalize_search_text(address),
                    internal_number, normalize_internal_number(internal_number),
                    comment, normalize_search_text(comment),
                    upload_time,
                ))
                if len(batch) >= BATCH_SIZE:
                    flush_batch()
            except Exception as exc:
                errors += 1
                print(f"[IMPORT] Ошибка строки {row_index}: {exc}")

        flush_batch()
        conn.commit()
        message = f"Добавлено: {inserted}; дубликатов: {duplicates}; пустых ШПИ: {skipped_empty}; ошибок: {errors}"
        return True, message

    except Exception as exc:
        print(f"[IMPORT] Критическая ошибка: {exc}")
        return False, str(exc)
    finally:
        if conn is not None:
            conn.close()
        if workbook is not None:
            workbook.close()
        if delete_source and file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass
